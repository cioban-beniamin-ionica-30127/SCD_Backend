package com.proiect.scd.proiectSCD.dtos;

import lombok.Data;

@Data
public class LoginRequest {
    private String username;
    private String password;
}
