package com.proiect.scd.proiectSCD.dtos;

import lombok.Data;

@Data
public  class RecipientDetails {
        private String name;
        private String email;
    }