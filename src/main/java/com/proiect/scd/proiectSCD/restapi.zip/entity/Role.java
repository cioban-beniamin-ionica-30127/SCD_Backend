package com.proiect.scd.proiectSCD.entity;

public enum Role {
    ADMIN,
    DIRECTOR
}
